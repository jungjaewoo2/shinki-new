# 🚀 프로젝트 개발환경 가이드

## 📋 기본 기술 스택

### 🏗️ **핵심 프레임워크**
- **프레임워크**: Spring Boot 2.7.5
- **빌드 도구**: Gradle 8.2.1
- **Java 버전**: JDK 1.8
- **웹 서버**: 내장 Tomcat (Spring Boot Starter Tomcat)
- **패키징**: WAR 파일

### 🎨 **프론트엔드 기술**
- **뷰 엔진**: JSP (Java Server Pages)
- **템플릿 엔진**: Apache Tiles 3.0.8
- **JSTL**: Java Standard Tag Library
- **JavaScript**: jQuery
- **에디터**: CKEditor

### 🗄️ **데이터베이스 & ORM**
- **데이터베이스**: MySQL 8.0.25
- **ORM**: MyBatis 2.2.0
- **SQL 로깅**: Log4jdbc-log4j2 1.16

## 🔧 주요 라이브러리

### 📦 **핵심 의존성**
```gradle
// Spring Boot
implementation 'org.springframework.boot:spring-boot-starter-web'
implementation 'org.springframework.boot:spring-boot-starter-cache'

// JSP & JSTL
implementation 'org.apache.tomcat.embed:tomcat-embed-jasper'
implementation 'javax.servlet:jstl'

// 템플릿 엔진
implementation group: 'org.apache.tiles', name: 'tiles-jsp', version: '3.0.8'

// 데이터베이스
implementation group: 'mysql', name: 'mysql-connector-java', version: '8.0.25'
implementation group: 'org.mybatis.spring.boot', name: 'mybatis-spring-boot-starter', version: '2.2.0'
implementation group: 'org.bgee.log4jdbc-log4j2', name: 'log4jdbc-log4j2-jdbc4.1', version: '1.16'

// 유틸리티
compileOnly 'org.projectlombok:lombok'
implementation 'com.google.code.gson:gson:2.9.0'
implementation group: 'commons-io', name: 'commons-io', version: '2.11.0'
implementation group: 'commons-fileupload', name: 'commons-fileupload', version: '1.4'
```

### 📊 **파일 처리**
```gradle
// 이미지 처리
implementation group: 'net.coobird', name: 'thumbnailator', version: '0.4.20'

// 엑셀 처리
implementation group: 'net.sf.jxls', name: 'jxls-core', version: '1.0.6'
implementation group: 'org.apache.poi', name: 'poi', version: '3.11'

// JSON 처리
implementation group: 'com.googlecode.json-simple', name: 'json-simple', version: '1.1.1'
```

### 🌐 **HTTP & 텍스트 처리**
```gradle
implementation 'org.apache.httpcomponents.client5:httpclient5:5.2'
implementation 'org.apache.commons:commons-text:1.10.0'
```

### 📚 **외부 JAR 라이브러리**
```gradle
// WEB-INF/lib 디렉토리에 위치
implementation name: 'jsinbi-1.6.2'
implementation name: 'teledit_jvm_1.8_1.2.9'
```

## ⚙️ 개발 환경 설정

### 🔧 **application.properties 기본 설정**
```properties
# 포트 설정
server.port=8080

# 세션 타임아웃 (10시간)
server.servlet.session.timeout=36000

# 인코딩 설정
server.servlet.encoding.charset=UTF-8
server.servlet.encoding.force=true

# JSP 설정
spring.mvc.view.prefix=/WEB-INF/jsp/
spring.mvc.view.suffix=.jsp
server.servlet.jsp.init-parameters.development=true

# 파일 업로드 (무제한)
spring.servlet.multipart.max-file-size=-1
spring.servlet.multipart.max-request-size=-1

# MyBatis 설정
mybatis.mapper-locations=classpath:mapper/**.xml, classpath:mapper/**/**.xml
mybatis.configuration.map-underscore-to-camel-case=true
mybatis.type-aliases-package=campain.vo

# Log4jdbc 설정
logging.level.jdbc.sqlonly=off
logging.level.jdbc.sqltiming=info
```

### 🗄️ **데이터베이스 설정 (local 환경)**
```properties
spring.datasource.driverClassName=net.sf.log4jdbc.sql.jdbcapi.DriverSpy
spring.datasource.url=jdbc:log4jdbc:mysql://zetta-system.iptime.org:53306/campaign?autoReconnection=true&useUnicode=true&characterEncoding=utf8
spring.datasource.username=root
spring.datasource.password=topy2u2018
```

## 🚀 새 프로젝트 생성 가이드

### 1. **Spring Boot 프로젝트 생성**
- Spring Boot 2.7.5 버전 선택
- Gradle 빌드 도구 선택
- WAR 패키징 방식 선택
- JDK 1.8 사용

### 2. **필수 의존성 추가**
위의 `build.gradle` 의존성들을 그대로 복사하여 추가

### 3. **외부 JAR 라이브러리 설정**
- `src/main/webapp/WEB-INF/lib/` 디렉토리 생성
- `jsinbi-1.6.2.jar`, `teledit_jvm_1.8_1.2.9.jar` 파일 추가
- `build.gradle`에 flatDir 설정 추가

### 4. **설정 파일 구성**
- `application.properties` 기본 설정 복사
- 환경별 프로파일 설정 (local, prod)
- 데이터베이스 연결 정보 수정

### 5. **프로젝트 구조 생성**
- 위의 디렉토리 구조에 맞게 패키지 생성
- MyBatis 매퍼 XML 파일 위치 설정

## 🔍 주요 특징

- **Spring Boot + JSP + MyBatis** 기반의 전형적인 한국형 웹 애플리케이션
- **Apache Tiles**를 활용한 레이아웃 템플릿 시스템
- **Log4jdbc**를 통한 SQL 로깅 및 성능 모니터링
- **Lombok**을 활용한 보일러플레이트 코드 제거
- **Gradle** 빌드 시스템으로 의존성 관리
- **WAR 패키징**으로 외부 Tomcat 배포 가능

## 📝 참고사항
- 이 환경은 **Spring Boot 2.7.5** 기준으로 작성되었습니다
- **JDK 1.8** 이상이 필요합니다
- **MySQL 8.0** 이상을 권장합니다