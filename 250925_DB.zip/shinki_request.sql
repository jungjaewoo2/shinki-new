-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: shinki
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `application_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `privacy_agreed` bit(1) NOT NULL,
  `privacy_agreement` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `member_id` bigint NOT NULL,
  `req_condition` int DEFAULT '1',
  `reg_condition` int NOT NULL,
  `status_cancel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_amount` bigint DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `money` bigint DEFAULT NULL,
  `admin_file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKlgy36p5youj5oe1irwbit23ct` (`member_id`),
  CONSTRAINT `FKlgy36p5youj5oe1irwbit23ct` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request`
--

LOCK TABLES `request` WRITE;
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
INSERT INTO `request` VALUES (14,'HBP','ㄴㅇㄹㅇㄴㄹㅇㄴㅁㄹㅇㄴㅁㄹㅇㄴㄹ\r\nㄴㅇㄹㄴㅇㅁㄹ\r\nㄹㅇ\r\nㅁㄴㅇㄹ\r\nㄴㅇㄹ\r\nㄴㅇㅁㄹㅇㄴㅁㄹㄴㅇㅁㄻㄴ','2025-09-21 11:51:49.483915','1758455509457_nas 연동.zip',_binary '','dffsdfdsfs','취소 완료','의뢰하기','2025-09-23 23:09:57.846254',123,1,1,'취소 완료',NULL,NULL,NULL,NULL,NULL),(15,'HBP','ㅇㄹㄴㅇㄹㅇㄴㄹㅇㄴㄹㄴ\r\nㅇㄴㄹㅇㄴㄹㅇㄴㄹㄴㅇㄹ\r\nㄴㅇㄹㄴㅇㄹㅇㄴ','2025-09-23 16:27:20.179000','1758644840142_db.zip',_binary '','서비스 의뢰 동의서에 동의합니다.','작업 완료','HBP 의뢰','2025-09-24 19:12:34.677479',123,1,1,'취소 요청',1000000,NULL,NULL,NULL,'1758741154604_메인1.jpg|1758741154640_상세.jpg'),(16,'LUNG','ㅂㅂㅂㅂㅂㅂㅂㅂ\r\nㅂㅂㅂㅂㅂ\r\nㅂㅂㅂㅂㅂㅂ','2025-09-24 12:47:07.397154','1758718027371_수정사항.zip',_binary '','서비스 의뢰 동의서에 동의합니다.','작업 완료','lung 의뢰','2025-09-24 12:47:24.836271',123,1,5,'N',NULL,NULL,NULL,NULL,NULL),(17,'LUNG','ㅈㅈㅈㅈㅈㅈㅈㅈ\r\nㅈㅈㅈㅈㅈㅈ','2025-09-24 19:42:53.229350','1758742973200_수정사항.zip',_binary '','서비스 의뢰 동의서에 동의합니다.','의뢰 확인중','의뢰하기 중임','2025-09-24 19:42:53.229350',734,1,1,'N',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `request` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-25  6:08:05
