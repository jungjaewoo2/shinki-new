-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: shinki
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `con_reg`
--

DROP TABLE IF EXISTS `con_reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `con_reg` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '상담 등록 번호',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '이름',
  `hospital_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '병원명',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '전화번호',
  `consultation_date` date NOT NULL COMMENT '상담날짜',
  `consultation_time` time NOT NULL COMMENT '상담시간',
  `consultation_content` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '상담내용',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '대기' COMMENT '상태 (대기, 진행중, 완료)',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '등록일시',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='상담 등록';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `con_reg`
--

LOCK TABLES `con_reg` WRITE;
/*!40000 ALTER TABLE `con_reg` DISABLE KEYS */;
INSERT INTO `con_reg` VALUES (1,'정재우','재우병원','01212121','2025-09-26','14:37:00','ㅇㄹㄴㅇㄹㅇㄹㅇㄴㄹㅇㄴㄹㅇㄹ\r\nㄴㅇㄹㅇㄴㄹㄴㅇㄹㅇㄴㄹ','대기','2025-09-23 05:33:45','2025-09-23 05:33:45'),(2,'정재일','재일병원','024662357','2025-09-23','13:42:00','상담하고파\r\n이제 상담하자','대기','2025-09-23 05:39:55','2025-09-23 05:39:55');
/*!40000 ALTER TABLE `con_reg` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-25  6:08:05
