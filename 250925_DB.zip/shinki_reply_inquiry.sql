-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: shinki
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reply_inquiry`
--

DROP TABLE IF EXISTS `reply_inquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reply_inquiry` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '댓글 ID',
  `inquiry_id` bigint NOT NULL COMMENT '문의 ID',
  `member_id` bigint DEFAULT NULL COMMENT '회원 ID (댓글 작성자)',
  `admin_no` bigint DEFAULT NULL COMMENT '관리자 번호 (답변 작성자)',
  `user_content` text COLLATE utf8mb4_unicode_ci COMMENT '사용자 댓글 내용',
  `admin_content` text COLLATE utf8mb4_unicode_ci COMMENT '관리자 답변 내용',
  `user_created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '사용자 댓글 작성일시',
  `admin_created_at` timestamp NULL DEFAULT NULL COMMENT '관리자 답변 작성일시',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
  PRIMARY KEY (`id`),
  KEY `inquiry_id` (`inquiry_id`),
  KEY `member_id` (`member_id`),
  KEY `admin_no` (`admin_no`),
  CONSTRAINT `reply_inquiry_ibfk_1` FOREIGN KEY (`inquiry_id`) REFERENCES `inquiry` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reply_inquiry_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reply_inquiry_ibfk_3` FOREIGN KEY (`admin_no`) REFERENCES `admin` (`admin_no`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='문의 댓글 및 답변';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reply_inquiry`
--

LOCK TABLES `reply_inquiry` WRITE;
/*!40000 ALTER TABLE `reply_inquiry` DISABLE KEYS */;
INSERT INTO `reply_inquiry` VALUES (2,99,123,4,'댓글달기\r\n댓글달기 1','답변요\r\n답변용','2025-09-21 04:33:27','2025-09-21 04:33:47',NULL,NULL),(3,99,123,4,'댓글달기1\r\n댓글달기2','확인하세요','2025-09-21 05:23:52','2025-09-21 16:59:23',NULL,NULL),(4,100,123,33,'댓글 문ㄴ의요','sdfdfasdfasdfdasf\r\nasdfsdfasdfasdfadsf','2025-09-21 17:01:03','2025-09-23 15:52:49',NULL,NULL),(5,100,123,NULL,'1234',NULL,'2025-09-23 15:41:33',NULL,NULL,NULL);
/*!40000 ALTER TABLE `reply_inquiry` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-25  6:08:06
