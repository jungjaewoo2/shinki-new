-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: shinki
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reply_request`
--

DROP TABLE IF EXISTS `reply_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reply_request` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '댓글 ID',
  `request_id` bigint NOT NULL COMMENT '의뢰 ID',
  `member_id` bigint DEFAULT NULL COMMENT '회원 ID (댓글 작성자)',
  `admin_no` bigint DEFAULT NULL COMMENT '관리자 번호 (답변 작성자)',
  `user_content` text COLLATE utf8mb4_unicode_ci COMMENT '사용자 댓글 내용',
  `admin_content` text COLLATE utf8mb4_unicode_ci COMMENT '관리자 답변 내용',
  `user_created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '사용자 댓글 작성일시',
  `admin_created_at` timestamp NULL DEFAULT NULL COMMENT '관리자 답변 작성일시',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
  `parent_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `request_id` (`request_id`),
  KEY `member_id` (`member_id`),
  KEY `admin_no` (`admin_no`),
  CONSTRAINT `reply_request_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `request` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reply_request_ibfk_2` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reply_request_ibfk_3` FOREIGN KEY (`admin_no`) REFERENCES `admin` (`admin_no`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='의뢰 댓글 및 답변';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reply_request`
--

LOCK TABLES `reply_request` WRITE;
/*!40000 ALTER TABLE `reply_request` DISABLE KEYS */;
INSERT INTO `reply_request` VALUES (1,14,123,NULL,'믄의사항압니다\r\nㄴㅇㄻㅇㄴㄹㅇㅁㄴㄹ',NULL,'2025-09-21 16:58:37',NULL,NULL,NULL,NULL),(2,15,123,NULL,'ddddddd',NULL,'2025-09-23 13:09:16',NULL,'2025-09-23 13:09:16','2025-09-23 13:09:16',NULL),(5,15,NULL,NULL,NULL,'답변을 햇습니다\r\n감사',NULL,'2025-09-23 13:25:14','2025-09-23 13:25:14','2025-09-23 13:25:14',2),(6,15,NULL,NULL,NULL,'또 답변을 합니다\r\n안녕',NULL,'2025-09-23 13:26:46','2025-09-23 13:26:46','2025-09-23 13:26:46',2),(7,15,123,NULL,'댓글 2번째\r\n문의',NULL,'2025-09-23 13:30:01',NULL,'2025-09-23 13:30:01','2025-09-23 13:30:01',NULL),(8,15,NULL,NULL,NULL,'답글을 2번째 \r\n단다',NULL,'2025-09-23 13:30:28','2025-09-23 13:30:28','2025-09-23 13:30:28',7);
/*!40000 ALTER TABLE `reply_request` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-25  6:08:06
